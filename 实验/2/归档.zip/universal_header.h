#ifndef UNIVERSAL_H
#define UNIVERSAL_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define max_element_count 100
#define max_str_length 10
#define ERROR 1
#define OK 0

#define max(a,b) (a>b?a:b)

#endif //UNIVERSAL_H